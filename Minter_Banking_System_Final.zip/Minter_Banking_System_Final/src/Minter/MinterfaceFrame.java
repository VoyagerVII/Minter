package Minter;

import java.awt.FlowLayout;
import javax.swing.JFrame;

//*//*
public class MinterfaceFrame extends Bankaccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		// LOG-IN FRAME
		MinterfaceGUI FrameObject = new MinterfaceGUI();//Creates ColoringFrame object
		
		// USER DASHBOARD FRAME
		//MinterfaceUserFrame FrameTest = new MinterfaceUserFrame();
		
		// USER SETTINGS & PREFERENCES FRAME
		
		// ADMIN MENU FRAME
		
		// 
				
		FrameObject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Closes Application upon close
		FrameObject.setSize(684,412); //Sets size to 300 by 300
		FrameObject.setVisible(true); //Set as visible
				
	}			
}
//*//*
